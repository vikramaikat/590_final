import gym
from gym import error, spaces, utils
from gym.utils import seeding
import numpy as np
import random

class ImageEnv(gym.Env):

    def __init__(self):
        super(ImageEnv, self).__init__()
        # TODO: read dataframe, set action space, state space
        # upload the dataset
        self.dataset = np.load('mnist_test_seq.npy')
        
        # set episode_over as False
        self.episode_over = False

        # sample a video and set first frame
        self.sample = random.randint(0, 9999)
        self.frame_num = 0
        self.image = self.dataset[self.frame_num][self.sample]

        # get parameter for noise images 
        # TODO: need to change the format if we have more parameters for noise parameters
        self.observation_space = spaces.Tuple((spaces.Box(0.0, 10, shape=[1]),\
                                              spaces.Box(0.0, 255, shape = [64, 64, 2])))
        self.action_space = spaces.Box(0.0, 10, shape=[1])

    def step(self, action):
        

        # TODO: noise video we noise video
        

        # TODO: need denoise function based on from action denoise


        # get reward
        reward = 0
        
        # move to next frame
        self.frame_num += 1
        self.image = self.dataset[self.frame_num][self.sample]
        
        # check whether frame is over
        if self.frame_num >= 19:
            self.episode_over = True
        obs = (action,self.image)

        return obs, reward, self.episode_over, {}, self.image

    def get_reward(self, action):
        # get reward
        pass

    def reset(self):
        # resample video from the dataset
        self.sample = random.randint(0, 9999)
        self.frame_num = 0
        self.image = self.dataset[self.frame_num][self.sample]
        self.episode_over = False

        # reset noise parameters

    def close(self):
        pass
