import gym
from gym import error, spaces, utils
from gym.utils import seeding
import numpy as np
import random
from scipy import ndimage
from scipy.signal.signaltools import wiener
import scipy
import cv2 as cv
from skimage.metrics import structural_similarity as ssim
import warnings

class ImageEnv(gym.Env):

    def __init__(self):
        super(ImageEnv, self).__init__()
        # TODO: read dataframe, set action space, state space
        # upload the dataset
        self.dataset = np.load('./gym_image/envs/mnist_test_seq.npy')
        # self.dataset = self.dataset[0:4]

        # gaussian noise
        self.mu = np.random.uniform(5,15,1)[0]
        self.sigma = 10

        # salt and paper
        ratio = np.random.uniform(0,1,1)[0]
        self.white_ratio = ratio
        self.black_ratio = ratio
        
        # set episode_over as False
        self.episode_over = False

        # sample a video and set first frame
        self.sample = random.randint(0, 7999)
        self.frame_num = 0
        self.image = self.dataset[self.frame_num][self.sample]
        self.obs = np.zeros((64,64,2))
        self.prev_image = np.zeros((64,64))

        # get parameter for noise images 
        # TODO: need to change the format if we have more parameters for noise parameters
        # self.observation_space = spaces.Tuple((spaces.Box(0.0, 10, shape=[1]),\
                                            #   spaces.Box(0.0, 255, shape = [64, 64, 2])))
        self.observation_space = spaces.Box(0.0, 255, shape = [64, 64, 2])

        # discrete model 
        # self.action_space = spaces.Discrete(5)
        action_low = [0.0, 0.0, 1.0]
        action_high = [2, 10000, 10]
        self.action_space = spaces.Box(np.array(action_low), np.array(action_high))
    
    def set_reward(self, ssi = 1/3, var = 1/3, of = 1/3):
        self.ssi = ssi
        self.var = ssi
        self.of = of

    def step(self, action):
        
        # TODO: need denoise function based on from action denoise
        # if action[0] == 1:
        #     self.filter_image =  gaussian_filter(self.noise_image, 0.5)
        # elif action[0] == 2:
        #     self.filter_image =  gaussian_filter(self.noise_image, 1)
        # elif action[0] == 3:
        #     self.filter_image =  wiener_filter(self.noise_image, 1)
        # elif action[0] == 4:
        #     self.filter_image =  wiener_filter(self.noise_image, 2)
        # elif action[0] == 5:
        #     self.filter_image =  median_filter(self.noise_image, 2)
        # else:
        #     self.filter_image =  median_filter(self.noise_image, 3)
        self.filter_image =  gaussian_filter(self.noise_image, action[0])
        self.filter_image = wiener_filter(self.filter_image, action[1])
        self.filter_image = median_filter(self.filter_image, action[2])

        # TODO: get reward
        reward = self.get_reward()
        
        # move to next frame
        self.frame_num += 1
        self.prev_image = self.image.copy()
        self.image = self.dataset[self.frame_num][self.sample]
        # TODO: noise video we noise video
        self.prev_noise_image = self.noise_image.copy()
        if self.noise == "gaussian":
            self.noise_image = add_gaussian_noise(self.image, self.mu, \
                self.sigma, shape=(64,64))
        elif self.noise == "gamma":
            self.noise_image = add_gamma_noise(self.image, self.gamma_shape,\
                 self.gamma_scale)
        else:
            self.noise_image = add_sandp_noise(self.image, self.white_ratio, \
                self.black_ratio, shape=(64,64))
        
        # check whether frame is over
        if self.frame_num >= 19:
            self.episode_over = True
        self.obs[:,:,0] = self.filter_image
        self.obs[:,:,1] = self.noise_image

        return self.obs, reward, self.episode_over, {}
        # return (self.obs, reward, self.episode_over, {}, \
        #     self.image, self.noise_image, self.filter_image)

    def get_reward(self):
        reward = 0
        total_perc = 0
        # calculate SSI for filter image and current true image
        reward += self.ssi * get_SSI(self.image, self.filter_image)
        total_perc += self.ssi
        # calculate variance for sharpness
        reward += self.var * (1-((np.var(self.image) - np.var(self.filter_image)) / \
            np.var(self.image)))
        total_perc += self.var
        if self.frame_num > 1:
            # calculate SSI for last filter image and current filter image
            # reward += get_SSI(self.obs[:,:,0], self.filter_image)
            reward += self.of * get_optical_flow_reward(self.filter_image, self.image, \
                self.obs[:,:,0], self.prev_image)
            total_perc += self.of
        # mse = reward_resolution(self.image, self.filter_image)
        if total_perc == 0:
            return(0)
        else:
            return (reward/total_perc)

    def reset(self, train = True):
        # resample video from the dataset
        if train:
            self.sample = random.randint(0, 7999)
        else:
            self.sample = random.randint(8000, 9999)
        self.frame_num = 0
        self.image = self.dataset[self.frame_num][self.sample]
        self.episode_over = False

        percentage = np.random.uniform(0,1,1)[0]
        if percentage <= 0.33:
            self.noise = "gaussian"
            # resample noise
            self.mu = np.random.uniform(5,15,1)[0]
            self.sigma = 10
        elif (percentage > 0.33) and (percentage <= 0.66):
            self.noise = "gamma"
            # resample noise
            self.gamma_shape = np.random.uniform(0,15,1)[0]
            self.gamma_scale = np.random.uniform(0,15,1)[0]
        else:
            self.noise = "salt_pepper"
            # resample noise parameter
            ratio = np.random.uniform(0,1,1)[0]
            self.white_ratio = ratio
            self.black_ratio = ratio


        # reset observation space
        self.obs = np.zeros((64,64,2))
        if self.noise == "gaussian":
            self.noise_image = add_gaussian_noise(self.image, self.mu, \
                self.sigma, shape=(64,64))
        elif self.noise == "gamma":
            self.noise_image = add_gamma_noise(self.image, self.gamma_shape, self.gamma_scale)
        else:
            self.noise_image = add_sandp_noise(self.image, self.white_ratio, \
                self.black_ratio, shape=(64,64))
        self.obs[:,:,1] = self.noise_image

        return(self.obs)

        # reset noise parameters
    
    def get_image(self):
        return(self.prev_image,self.prev_noise_image,self.filter_image)

    def close(self):
        pass

# helper function

def add_sandp_noise(img, white_ratio, black_ratio, shape=(64,64)):
  img_altered = img.copy()
  row, col = img_altered.shape
  for i in range(int(white_ratio * (row * col))):
    img_altered[random.randint(0, row-1)][random.randint(0,col-1)] = 255
  for i in range(int(black_ratio * (row * col))):
    img_altered[random.randint(0, row-1)][random.randint(0,col-1)] = 0
  return img_altered

def add_gaussian_noise(img, mu, sigma, shape=(64,64)):
  noise = np.random.normal(mu, sigma, shape)
  noise[noise < 0] = 0
  noise[noise > 255] = 255
  return img + noise

def add_gamma_noise(img, gamma_shape, scale, shape=(64,64)):
  noise = np.random.gamma(gamma_shape, scale, shape)
  noise[noise < 0] = 0
  noise[noise > 255] = 255
  return img + noise

def gaussian_filter(img, action):
    filter_image = scipy.ndimage.gaussian_filter(img, action)
    filter_image[filter_image < 0] = 0
    filter_image[filter_image > 255] = 255
    return filter_image

def wiener_filter(img, action):

    with warnings.catch_warnings():
        warnings.filterwarnings('error')
        img = img.astype('float64')
        try:
            filter_image = wiener(img, noise = action)
            filter_image[filter_image < 0] = 0
            filter_image[filter_image > 255] = 255
            return filter_image
        except RuntimeWarning:
            return(img)

def median_filter(img, action):
    filter_image = scipy.ndimage.median_filter(img, size = int(action))
    return(filter_image)

def reward_resolution(img, filter_img):
    mse = ((img - filter_img)**2).mean(axis=None)
    return mse

def get_SSI(true_image, filter_image):
    with warnings.catch_warnings():
        warnings.filterwarnings('error')
        try:
            reward = ssim(true_image, filter_image, \
                data_range=filter_image.max() - filter_image.min())
            return (reward)
        except RuntimeWarning:
            return (0)

def get_optical_flow_reward(filter_image, image, previous_filter_image, previous_image):
    flow_current = cv.calcOpticalFlowFarneback(previous_filter_image,filter_image, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    true_flow = cv.calcOpticalFlowFarneback(previous_image,image, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    return get_SSI(true_flow[:,:,0], flow_current[:,:,0])